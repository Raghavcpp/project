import os
if os.path.exists("output/ajathINDIAtext.png"):
  os.remove("output/ajathINDIAtext.png")
else:
  print("The file does not exist")
if os.path.exists("output/ajathARABtext.png"):
  os.remove("output/ajathARABtext.png")
else:
  print("The file does not exist")
if os.path.exists("output/ajathUSAtext.png"):
  os.remove("output/ajathUSAtext.png")
else:
  print("The file does not exist")